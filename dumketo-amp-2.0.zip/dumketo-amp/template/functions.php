<?php
/*
Name: Function
Developer: Hasan Ahmed Jobayer
*/