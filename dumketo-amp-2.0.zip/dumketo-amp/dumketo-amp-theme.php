<?php
/*
Plugin Name: dumketo Amp theme
Plugin URI: http://dumketo.github.io/Resume/
Description: This is a custom AMP theme Made by Hasan Ahmed Jobayer (dumketo).
Version: 2.0
Author:  Hasan Ahmed Jobayer
License: GPL2
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

//Social Icons
add_amp_theme_support('AMP-social-icons');

// Define the Folder of the theme.
define('AMPFORWP_CUSTOM_THEME', plugin_dir_path( __FILE__ ));

// Remove old files
add_action('init','ampforwp_custom_theme_remove_old_files',11);
function ampforwp_custom_theme_remove_old_files(){
    remove_action('pre_amp_render_post','ampforwp_stylesheet_file_insertion', 12 );
	remove_filter( 'amp_post_template_file', 'ampforwp_custom_header', 10, 3 );
	if ( is_single() ) {
		remove_filter( 'amp_post_template_file', 'ampforwp_custom_template', 10, 3 );
	}
	add_action('amp_post_template_head', function() {
		remove_action( 'amp_post_template_head', 'amp_post_template_add_fonts');
	}, 9);
}


// Register New Files
add_action('init','ampforwp_custom_theme_files_register', 10);
function ampforwp_custom_theme_files_register(){
	add_filter( 'amp_post_template_file', 'ampforwp_custom_header_file', 10, 2 );
	add_filter( 'amp_post_template_file', 'ampforwp_designing_custom_template', 10, 3 );
	add_filter( 'amp_post_template_file', 'ampforwp_custom_footer_file', 10, 2 );
	add_filter( 'amp_post_template_file', 'ampforwp_custom_footer_part_file', 10, 2 );
	add_filter( 'amp_post_template_file', 'ampforwp_custom_map_file', 10, 2 );
	add_filter( 'amp_post_template_file', 'ampforwp_custom_service_file', 10, 2 );
	add_filter( 'amp_post_template_file', 'ampforwp_custom_related_posts_file', 10, 2 );
}


// Custom Header
function ampforwp_custom_header_file( $file, $type ) {
	if ( 'header-bar' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/header-bar.php';
	}
	return $file;
}

// Custom Template Files
function ampforwp_designing_custom_template( $file, $type, $post ) {

	// Single file
    if ( is_single() || is_page() ) {
		if('single' === $type && !('product' === $post->post_type )) {
			$file = AMPFORWP_CUSTOM_THEME . '/template/single.php';
	 	}
	}
    // Archive
	if ( is_archive() ) {
        if ( 'single' === $type ) {
            $file = AMPFORWP_CUSTOM_THEME . '/template/archive.php';
        }
    }
    // Homepage
	if ( is_home() ) {
        if ( 'single' === $type ) {
            $file = AMPFORWP_CUSTOM_THEME . '/template/index.php';
        }
    }

 	return $file;
}

function ampforwp_custom_related_posts_file( $file, $type ) {
	if ( 'related-posts' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/elements/related-posts.php';
	}
	return $file;
}

// Custom Footer
function ampforwp_custom_map_file( $file, $type ) {
	if ( 'map' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/footer-part/map.php';
	}
	return $file;
}
function ampforwp_custom_service_file( $file, $type ) {
	if ( 'service' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/footer-part/service.php';
	}
	return $file;
}
function ampforwp_custom_footer_part_file( $file, $type ) {
	if ( 'footer-part' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/footer-part/footer-part.php';
	}
	return $file;
}
function ampforwp_custom_footer_file($file, $type ){
	if ( 'footer' === $type ) {
		$file = AMPFORWP_CUSTOM_THEME . '/template/footer.php';
	}
    return $file;
}


add_action( 'amp_post_template_head', 'amp_post_template_add_custom_google_font');
// Loading Custom Google Fonts in the theme
function amp_post_template_add_custom_google_font( $amp_template ) {
    global $redux_builder_amp;
    if( $redux_builder_amp['activate_font'] == 1 ): ?>
        <link rel="stylesheet" href="<?php echo esc_url( $redux_builder_amp['font_url'] ); ?>">
    <?php else: 
        $font_urls = $amp_template->get( 'font_urls', array() );
    	$font_urls['source_serif_pro'] = 'https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600|Source+Sans+Pro:400,700';  ?>
        <link rel="stylesheet" href="<?php echo esc_url( $font_urls['source_serif_pro'] ); ?>">
    <?php endif;
}

// Loading Core Styles
require_once( AMPFORWP_CUSTOM_THEME . '/template/style.php' );
require_once( AMPFORWP_CUSTOM_THEME . '/template/functions.php' );
require_once( AMPFORWP_CUSTOM_THEME . '/template/inc/review-snippet.php' );
require_once( AMPFORWP_CUSTOM_THEME . '/template/inc/schema.php' );


// Add Scripts only when AMP Menu is Enabled
if( has_nav_menu( 'amp-menu' ) ) {
    if ( empty( $data['amp_component_scripts']['amp-accordion'] ) ) {
        $data['amp_component_scripts']['amp-accordion'] = 'https://cdn.ampproject.org/v0/amp-accordion-0.1.js';
    }
}

// Customize by dumketo
add_action( 'in_admin_footer', 'meta_enqueue_scripts' );
function meta_enqueue_scripts() {
    require_once( AMPFORWP_CUSTOM_THEME . '/template/inc/admin.php' );
}

require ( AMPFORWP_CUSTOM_THEME .'update/plugin-update-checker.php' );
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://github.com/dumketo/dumketo-amp/raw/master/plugin.json',
	__FILE__,
	'dumketo-amp'
);
