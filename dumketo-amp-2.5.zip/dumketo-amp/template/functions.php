<?php
/*
Name: Function
Developer: Hasan Ahmed Jobayer
*/

//Social Icons
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if ( is_plugin_active( 'accelerated-mobile-pages/accelerated-mobile-pages.php' ) ) {
	add_amp_theme_support('AMP-social-icons');
}