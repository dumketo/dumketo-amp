<?php 
/*
* Footer Service
* Developer: Hasan Ahmed Jobayer
*/

global $redux_builder_amp;
if ( $redux_builder_amp['service_switch'] == 1 ):
    if( $redux_builder_amp['damp_footer_service_list'] ):
?>
    <div class="footer-service-section">
        <h2><?php echo $redux_builder_amp['damp_footer_service_title'] ?></h2>
        <div class="clear"></div>
        <div class="amp-flex amp-service-flex">
            <?php foreach ( $redux_builder_amp['damp_footer_service_list'] as $key => $value ) :
                $page = get_page( $value ); ?>
                <a target="_blank" href="<?php echo $page->guid ?>"><?php echo $page->post_title ?></a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; endif; ?>
