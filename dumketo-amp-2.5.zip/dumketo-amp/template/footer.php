<?php
/*
* Footer Information
* Developer: Hasan Ahmed Jobayer
*/
?>
<footer class="container">
    <div id="footer">
        <p>
            &copy <?php echo date( "Y"); ?> <?php bloginfo( 'name' ); ?>. All Rights Reserved. | <a href="http://belocal.today/" target="_blank">BeLocal Today</a>
        </p>
    </div>
</footer>
<?php do_action('ampforwp_global_after_footer'); ?>
