<?php
global $redux_builder_amp;
if ( $redux_builder_amp['activate_schema']==1 ):
    add_action ( 'wp_head', 'Schema_info' );
    function Schema_info() {
        global $redux_builder_amp;
    ?>
        <script type="application/ld+json">
            {
                "@context": "http://schema.org",
                "@type": "Organization",
                "url": "<?php echo get_home_url(); ?>",
                "logo": "<?php echo $redux_builder_amp['opt-media']['url']; ?>",
                "sameAs" : [<?php foreach( $redux_builder_amp['damp_social_links'] as $key => $value): if ( $value ) : ?> "<?php echo $value; ?>", <?php endif; endforeach; ?>]
            }
        </script>
        <?php
        if ( $redux_builder_amp['schema_type'] ):
            foreach ( $redux_builder_amp['schema_type'] as $schema_type_id => $schema_type_value ) {
                $schema_type_value = explode(",", $schema_type_value);  ?>
                <script type="application/ld+json">
                {
                    "@context": "http://schema.org",
                    "@type": "<?php echo $schema_type_value[0]; ?>",
                    "url": "<?php echo get_home_url(); ?>",
                    "image": "<?php echo $redux_builder_amp['opt-media']['url']; ?>",
                    "name": "<?php echo $schema_type_value[1]; ?>",
                    "priceRange": "$$",
                    <?php if( $schema_type_value[0]=='Restaurant' ) { ?> "servesCuisine" : "<?php echo $schema_type_value[2]; ?>", <?php } ?>
                    "telephone": "<?php echo $redux_builder_amp['enable-amp-call-numberfield']; ?>",
                    "email": "<?php echo $redux_builder_amp['damp_info_email']; ?>",
                    "address":{
                        "@type"          :   "PostalAddress",
                        "streetAddress"  :   "<?php echo trim( $redux_builder_amp['streetAddress'] ); ?>",
                        "addressLocality":   "<?php echo trim( $redux_builder_amp['addressLocality'] ); ?>",
                        "addressRegion"  :   "<?php echo trim( $redux_builder_amp['addressRegion'] ); ?>",
                        "postalCode"     :   "<?php echo trim( $redux_builder_amp['postalCode'] ); ?>"
                    }
                }
                </script>
        <?php }
        endif;
    }
endif;
