<?php
/*
* Admin css For redux and cmb2 and post types
*/
?>

<style type="text/css">
    ul.redux-sortable input[type=text] { width: 600px; padding: 8px; }
    ul#damp_social_links-list li strong { text-transform: capitalize; font-size: 12pt; color: #000; }
    input#schema_type-0 { width: 80%; }
</style>
