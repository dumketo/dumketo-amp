<?php global $redux_builder_amp;
if ( $redux_builder_amp['map_switch']==1 ):
?>
<div class="map-section">
    <a target="_blank" href="<?php echo $redux_builder_amp['damp_map_link']; ?>">
        <amp-img src="<?php echo $redux_builder_amp['damp_map_image']['url'] ?>" width="<?php echo $redux_builder_amp['damp_map_image']['width'] ?>" height="<?php echo $redux_builder_amp['damp_map_image']['height'] ?>" alt="Google Map" class="amp-map"></amp-img>
    </a>
</div>
<?php endif; ?>
