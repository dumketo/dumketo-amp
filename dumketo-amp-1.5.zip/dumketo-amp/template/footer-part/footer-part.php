<?php global $redux_builder_amp; ?>
<div class="footer-info">
    <h2><?php echo $redux_builder_amp['damp_footer_info_title']; ?></h2>
    <p><?php echo $redux_builder_amp['damp_info_address']; ?></p>
    <p><a href="tel:<?php echo $redux_builder_amp['enable-amp-call-numberfield']; ?>"><?php echo $redux_builder_amp['enable-amp-call-numberfield']; ?></a></p>
    <p><a href="mailto:<?php echo $redux_builder_amp['damp_info_email']; ?>"><?php echo $redux_builder_amp['damp_info_email']; ?></a></p>
    <div class="amp-flex amp-social-flex-row">
        <?php foreach( $redux_builder_amp['damp_social_links'] as $key => $value): ?>
            <?php if ( $value ) : ?>
            <div class="p-2">
                <a target="_blank" href="<?php echo $value; ?>" class="<?php echo $key; ?>">
                    <span class="ice-icon icon-<?php echo $key; ?>"></span>
                </a>
            </div>
        <?php endif; ?>
        <?php endforeach;?>
    </div>
    <?php if( $redux_builder_amp['damp_gplus_review'] ): ?>
    <div class="google-review">
        <a target="_blank" href="<?php echo $redux_builder_amp['damp_gplus_review']; ?>">
            <?php echo $redux_builder_amp['damp_gplus_review_text']; ?>
        </a>
    </div>
    <?php endif; ?>
</div>
