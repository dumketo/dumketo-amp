<?php global $redux_builder_amp;  ?>
<!doctype html>
<html amp <?php echo AMP_HTML_Utils::build_attributes_string( $this->get( 'html_tag_attributes' ) ); ?>>
<head>
<meta charset="utf-8">
<link rel="dns-prefetch" href="https://cdn.ampproject.org">
<?php
global $redux_builder_amp;
if ( is_home() || is_front_page()  || ( is_archive() && $redux_builder_amp['ampforwp-archive-support'] ) ){
    global $wp;
    $current_archive_url = home_url( $wp->request );
    $amp_url 	= trailingslashit($current_archive_url);
    $remove 	= '/'. AMP_QUERY_VAR;
    $amp_url 	= str_replace($remove, '', $amp_url) ;
} ?>
	<?php do_action( 'amp_post_template_head', $this ); ?>
	<style amp-custom>
		<?php $this->load_parts( array( 'style' ) ); ?>
		<?php do_action( 'amp_post_template_css', $this ); ?>
	</style>
    <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
</head>
<body class="amp-index <?php echo esc_attr( $this->get( 'body_class' ) ); ?>">

<?php $this->load_parts( array( 'header-bar' ) ); ?>

<div class="amp-wp-article ampforwp-custom-index amp-wp-home">
    <?php do_action('ampforwp_post_before_design_elements') ?>
    <!-- Banner Slider Starts -->
    <?php $home_slider = $redux_builder_amp['home_slider']; ?>
    <?php if($redux_builder_amp['slider_switch'] == 1):?>
        <div class="banner-carrousel">
            <amp-carousel class="carousel2" width="1000" height="<?php echo $redux_builder_amp['slider_height'] ?>" type="slides" layout="responsive" autoplay delay="<?php echo $redux_builder_amp['slider_delay'] ?>">
                <?php foreach( $home_slider as $home_sliders ): ?>
                    <figure>
                        <amp-img src="<?php echo $home_sliders['image'];?>" layout="fill" attribution="visualhunt"></amp-img>
                        <figcaption><?php echo $home_sliders['title'];?></figcaption>
                    </figure>
                <?php endforeach;?>
            </amp-carousel>
        </div>
    <?php endif;?>
    <!-- Banner Slider Ends -->
    <!-- Loop Starts -->
    <?php if ( get_query_var( 'paged' ) ) { $paged = get_query_var('paged'); } elseif ( get_query_var( 'page' ) ) { $paged = get_query_var('page'); } else { $paged = 1; }
        $exclude_ids = get_option('ampforwp_exclude_post');
    	$args = array( 'post_type' => 'post', 'orderby' => 'date', 'paged' => esc_attr($paged), 'post__not_in' => $exclude_ids, 'has_password' => false , 'post_status'=> 'publish' );
    	$filtered_args = apply_filters('ampforwp_query_args', $args);
    	$q = new WP_Query( $filtered_args );
        $ampforwp_post_url = get_permalink();
        if ( $q->have_posts() ) : while ( $q->have_posts() ) : $q->the_post(); ?>
        <div class="amp-wp-content amp-wp-article-header amp-loop-list">
            <div class="amp-wp-post-content">
    			<h2 class="amp-wp-title"> <a href="<?php echo trailingslashit($ampforwp_post_url) . AMP_QUERY_VAR ;?>"> <?php the_title(); ?></a></h2>
    			<?php if(has_excerpt()){ $content = get_the_excerpt(); }else{ $content = get_the_content(); } ?>
    	        <p class="large-screen-excerpt">
    			<?php
    				$excerpt_length = "";
    				$excerpt_length = 15;
    				$final_content  = "";
    				$final_content = apply_filters('ampforwp_modify_index_content', $content,  $excerpt_length );
    				if ( false === has_filter('ampforwp_modify_index_content' ) ) {
    					$final_content = wp_trim_words( strip_shortcodes( $content ) ,  $excerpt_length );
    				}
    				echo $final_content;
    			?></p>
    	        <p class="small-screen-excerpt" > <?php
    				if($redux_builder_amp['excerpt-option-design-2']== true) {
    					$excerpt_length_2	='';
    					$excerpt_length_2 	= $redux_builder_amp['amp-design-2-excerpt'];
    					$final_content 		= "";
    					$final_content = apply_filters('ampforwp_modify_index_content', $content,  $excerpt_length );

    					if ( false === has_filter('ampforwp_modify_index_content' ) ) {
    						$final_content = wp_trim_words( strip_shortcodes( $content ) ,  $excerpt_length );
    					}
    					echo $final_content;
    				} ?>
    			</p>
    	    </div>
            <?php if ( ampforwp_has_post_thumbnail() ) {
    			$thumb_url = ampforwp_get_post_thumbnail();
    			if($thumb_url){ ?>
    				<div class="home-post_image">
    					<a href="<?php echo trailingslashit($ampforwp_post_url) . AMP_QUERY_VAR ;?>">
    						<amp-img src=<?php echo esc_url($thumb_url); ?>
        						<?php ampforwp_thumbnail_alt(); ?>
        							<?php if( $redux_builder_amp['ampforwp-homepage-posts-image-modify-size'] ) { ?>
        							width=<?php global $redux_builder_amp; echo $redux_builder_amp['ampforwp-homepage-posts-design-1-2-width'] ?>
        							height=<?php global $redux_builder_amp; echo $redux_builder_amp['ampforwp-homepage-posts-design-1-2-height'] ?>
        						<?php } else { ?>
        							width=100 height=75
        						<?php } ?>
    						></amp-img>
    					</a>
    				</div>
    			<?php }
    		} ?>
    	</div>
        <?php endwhile;  ?>
        <!-- Loop Ends -->

        <!-- Pagination Starts -->
        <div class="pagination-holder">
            <div id="pagination">
                <div class="prev"><?php previous_posts_link( '&laquo; '. $redux_builder_amp['amp-translator-previous-text'] ); ?></div>
                <div class="next"><?php next_posts_link( $redux_builder_amp['amp-translator-next-text']. ' &raquo;', 0 ) ?></div>
            </div>
        </div>
        <!-- Pagination Ends -->
    <?php endif; ?>
</div>
<?php $this->load_parts( array( 'map' ) ); ?>
<?php $this->load_parts( array( 'service' ) ); ?>
<?php $this->load_parts( array( 'footer-part' ) ); ?>
<?php $this->load_parts( array( 'footer' ) ); ?>
<?php do_action( 'amp_post_template_footer', $this ); ?>

</body>
</html>
