<?php
/*
Name: Theme Config
Developer: Hasan Ahmed Jobayer
*/

function add_dumketo_theme_functions($sections){
    $sections[] = array(
        'icon' => 'el-icon-wrench',
        'title' => __( 'Dumketo Settings', 'dumketo' ),
        'id'    => 'dumketo_theme_setting',
    );
    $sections[] = array(
        'title'            => __( 'General Section', 'dumketo' ),
        'id'               => 'header-Section',
        'subsection' => true,
        'fields'           => array(
            array(
                'id'       => 'activate_font',
                'type'     => 'switch',
                'title'    => __( 'Activate Font Style', 'dumketo' ),
                'default'  => 0,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'font_name',
                'type'     => 'text',
                'title'    => __('Fonts Name', 'dumketo'),
                'required' => array( 'activate_font', '=', '1' ),
            ),
            array(
                'id'       => 'font_url',
                'type'     => 'text',
                'title'    => __('Fonts Url', 'dumketo'),
                'class'    => 'large-text',
                'required' => array( 'activate_font', '=', '1' ),
            ),
        )
    );
    $sections[] = array(
        'title'            => __( 'Header Bar Section', 'dumketo' ),
        'id'               => 'header-Section',
        'subsection' => true,
        'fields'           => array(
            array(
                'title'    => __( 'Call Us Background Color', 'dumketo' ),
                'id'       => 'damp_call_us_background_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#d62323',
                ),
            ),
            array(
                'title'    => __( 'Call Us Font Color', 'dumketo' ),
                'id'       => 'damp_call_us_font_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#FFFFFF',
                ),
            ),
            array(
                'title'    => __( 'Menu Background Color', 'dumketo' ),
                'id'       => 'damp_menu_background_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#000000',
                ),
            ),
            array(
                'title'    => __( 'Menu Font Color', 'dumketo' ),
                'id'       => 'damp_menu_font_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#FFFFFF',
                ),
            ),
            array(
               'id' => 'section-start',
               'type' => 'section',
               'title' => __('Toggle Menu', 'dumketo'),
               'indent' => true
            ),
                array(
                    'title'    => __( 'Toggle Menu Background Color', 'dumketo' ),
                    'id'       => 'damp_toogle_menu_background_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#000000',
                    ),
                ),
                array(
                    'title'    => __( 'Toggle Menu Font Color', 'dumketo' ),
                    'id'       => 'damp_toggle_menu_font_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#FFFFFF',
                    ),
                ),
                array(
                    'title'    => __( 'Toggle Menu hover Background Color', 'dumketo' ),
                    'id'       => 'damp_toggle_menu_hover_background_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#000000',
                    ),
                ),
                array(
                    'title'    => __( 'Toggle Menu hover Font Color', 'dumketo' ),
                    'id'       => 'damp_toggle_menu_hover_font_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#FFFFFF',
                    ),
                ),
            array(
                'id'     => 'section-end',
                'type'   => 'section',
                'indent' => false,
            ),
        )
    );
    $sections[] = array(
        'title'            => __( 'Slider Section', 'dumketo' ),
        'id'               => 'slider-section',
        'subsection' => true,
        'fields'           => array(
            array(
                'id'       => 'slider_switch',
                'type'     => 'switch',
                'title'    => __('Home Slider Activation', 'dumketo'),
                'default'  => false,
            ),
            array(
                'id'     => 'slider_height',
                'title'  => 'Home Slider Height',
                'type'   => 'text',
                'placeholder'=>'400',
                'required' => array('slider_switch', '=' , '1'),
            ),
            array(
                'id'     => 'slider_delay',
                'title'  => 'Home Slider Delay',
                'type'   => 'text',
                'placeholder'=>'5000',
                'required' => array('slider_switch', '=' , '1'),
            ),
            array(
                'id'       => 'home_slider',
                'type'     => 'slides',
                'required' => array('slider_switch', '=' , '1'),
                'title'       => __( 'Home Slider', 'dumketo' ),
                'placeholder' => array(
                    'title'       => __('Home Slider Title', 'dumketo'),
                    'description' => __('Home Slider Description', 'dumketo'),
                    'url'         => __('Image Height', 'dumketo'),
                ),
            ),
        )
    );
    $sections[] = array(
        'title'            => __( 'Map & Service Section', 'dumketo' ),
        'id'               => 'dumketo-map-service',
        'subsection' => true,
        'fields'  => array(
            array(
               'id' => 'section-start',
               'type' => 'section',
               'title' => __('Map Section', 'dumketo'),
               'indent' => true
            ),
                array(
                    'id'       => 'map_switch',
                    'type'     => 'switch',
                    'title'    => __('Map Activation', 'dumketo'),
                    'default'  => false,
                ),
                array(
                    'id'       => 'damp_map_image',
                    'type'     => 'media',
                    'url'      => true,
                    'title'    => __( 'Map Image', 'dumketo' ),
                    'compiler' => 'true',
                    'required' => array('map_switch', '=' , '1'),
                ),
                array(
                    'title'    => __( 'Map Link', 'dumketo' ),
                    'id'       => 'damp_map_link',
                    'type'     => 'text',
                    'required' => array('map_switch', '=' , '1'),
                ),
            array(
                'id'     => 'section-end',
                'type'   => 'section',
                'indent' => false,
            ),

            array(
               'id' => 'section-start',
               'type' => 'section',
               'title' => __('Service Section', 'dumketo'),
               'indent' => true
            ),
                array(
                    'id'       => 'service_switch',
                    'type'     => 'switch',
                    'title'    => __('Footer Service Activation', 'dumketo'),
                    'default'  => false,
                ),
                array(
                    'title'    => __( 'Footer Service title', 'dumketo' ),
                    'id'       => 'damp_footer_service_title',
                    'type'     => 'text',
                    'required' => array('service_switch', '=' , '1'),
                ),
                array(
                    'title'    => __( 'Footer Service title Background Color', 'dumketo' ),
                    'id'       => 'damp_footer_service_title_background_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#000000',
                    ),
                    'required' => array('service_switch', '=' , '1'),
                ),
                array(
                    'title'    => __( 'Footer Service title Font Color', 'dumketo' ),
                    'id'       => 'damp_footer_service_title_font_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#000000',
                    ),
                    'required' => array('service_switch', '=' , '1'),
                ),
                array(
                    'title'    => __('Footer Service list', 'dumketo'),
                    'id'       => 'damp_footer_service_list',
                    'type'     => 'select',
                    'multi'    => true,
                    'data'     => 'pages',
                    'required' => array('service_switch', '=' , '1'),
                ),
                array(
                    'title'    => __( 'Footer Service hover Background Color', 'dumketo' ),
                    'id'       => 'damp_footer_service_hover_background_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#000000',
                    ),
                    'required' => array('service_switch', '=' , '1'),
                ),
                array(
                    'title'    => __( 'Footer Service hover font Color', 'dumketo' ),
                    'id'       => 'damp_footer_service_hover_font_color',
                    'type'     => 'color_rgba',
                    'default'   => array(
                        'color' => '#ffffff',
                    ),
                    'required' => array('service_switch', '=' , '1'),
                ),


            array(
                'id'     => 'section-end',
                'type'   => 'section',
                'indent' => false,
            ),
        )
    );
    $sections[] = array(
        'title'            => __( 'Social', 'dumketo' ),
        'id'               => 'dumketo-social',
        'subsection' => true,
        'fields'  => array(
            array(
                'id'       => 'damp_gplus_review',
                'type'     => 'text',
                'title'    => __( 'Google+ Review', 'dumketo' ),
            ),
            array(
                'id'       => 'damp_gplus_review_text',
                'type'     => 'text',
                'title'    => __( 'Google+ Review Text', 'dumketo' ),
            ),
            array(
                'title'    => __( 'Google+ Review Background Color', 'dumketo' ),
                'id'       => 'damp_gplus_review_background_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#dd4b39',
                ),
            ),
            array(
                'id'       => 'damp_social_links',
                'type'     => 'sortable',
                'title'    => __('Social Profiles', 'dumketo'),
                'mode'     => 'text',
                'label'    => true,
                'options' => array(
                    'facebook'      => '',
                    'google-plus'   => '',
                    'twitter'       => '',
                    'instagram'     => '',
                    'linkedin'      => '',
                    'youtube'       => '',
                ),
            ),
        )
    );
    $sections[] = array(
        'title'            => __( 'Footer Section', 'dumketo' ),
        'id'               => 'footer-section',
        'subsection' => true,
        'fields'  => array(
            array(
                'title'    => __( 'Footer Info Background', 'dumketo' ),
                'id'       => 'damp_footer_info_background',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#000000',
                ),
            ),
            array(
                'title'    => __( 'Footer Info Font Color', 'dumketo' ),
                'id'       => 'damp_footer_info_font_color',
                'type'     => 'color_rgba',
                'default'   => array(
                    'color' => '#FFFFFF',
                ),
            ),
            array(
                'title'    => __( 'Footer Info Title', 'dumketo' ),
                'id'       => 'damp_footer_info_title',
                'type'     => 'text'
            ),
            array(
                'title'    => __( 'Address', 'dumketo' ),
                'id'       => 'damp_info_address',
                'type'     => 'text',
            ),
            array(
                'title'    => __( 'Email', 'dumketo' ),
                'id'       => 'damp_info_email',
                'type'     => 'text',
            ),
        )
    );
    return $sections;
}
add_filter("redux/options/redux_builder_amp/sections", 'add_dumketo_theme_functions');

function add_dumketo_review_snippet($sections){
    $sections[] = array(
        'title' => __( 'Dumketo Review snippet', 'dumketo' ),
        'id'    => 'dumketo_review_snippet',
        'icon'  => 'el el-filter',
        'fields'  => array(
            array(
                'id'       => 'rating_switch',
                'type'     => 'switch',
                'title'    => __('Activate Rating Snippet', 'dumketo'),
                'default'  => false,
            ),
            array(
                'title'    => __( 'Google API Places Key ', 'dumketo' ),
                'id'       => 'damp_google_api_places_key',
                'desc'     => '1. Go to <a target="_blank" href="https://developers.google.com/places/web-service/get-api-key">Google Places API</a>; 2. Click by "GET A KEY" button; 3. Agree term and click by "CREATE AND ENABLE API"',
                'type'     => 'text',
                'required' => array( 'rating_switch', '=', '1' ),
            ),
            array(
                'title'    => __( 'Find a Place', 'dumketo' ),
                'id'       => 'damp_find_place',
                'type'     => 'text',
                'required' => array( 'rating_switch', '=', '1' ),
            ),
            array(
                'title'    => __( 'Total Reviews', 'dumketo' ),
                'id'       => 'damp_total_reviews',
                'type'     => 'text',
                'required' => array( 'rating_switch', '=', '1' ),
            ),
        )
    );
    return $sections;
}
add_filter("redux/options/redux_builder_amp/sections", 'add_dumketo_review_snippet');


function add_dumketo_schema($sections){
    $sections[] = array(
        'title' => __( 'Dumketo Schema', 'dumketo' ),
        'id'    => 'dumketo_schema',
        'icon'  => 'el el-info-circle',
        'fields'  => array(
            array(
            'id'       => 'activate_schema',
            'type'     => 'switch',
            'title'    => __( 'Activate Schema', 'dumketo' ),
            'default'  => 0,
            'on'       => 'Enabled',
            'off'      => 'Disabled',
            ),
            array(
                'title'    => __( 'Schema Type', 'dumketo' ),
                'required' => array( 'activate_schema', '=', '1' ),
                'id'       => 'schema_type',
                'type'     => 'multi_text',
                'class'    => 'large-text',
                'desc'     => __('FORMAT: First Schema Type then Name. example: "HomeAndConstructionBusiness, Window Cleaning Service" if Schema name "Restuarent" Then add "servesCuisine"  ', 'dumketo'),

            ),
            array(
                'title'    => __( 'Street Address', 'dumketo' ),
                'required' => array( 'activate_schema', '=', '1' ),
                'id'       => 'streetAddress',
                'type'     => 'text',
            ),
            array(
                'title'    => __( 'Address Locality', 'dumketo' ),
                'required' => array( 'activate_schema', '=', '1' ),
                'id'       => 'addressLocality',
                'type'     => 'text',
            ),
            array(
                'title'    => __( 'Address Region', 'dumketo' ),
                'required' => array( 'activate_schema', '=', '1' ),
                'id'       => 'addressRegion',
                'type'     => 'text',
            ),
            array(
                'title'    => __( 'Postal Code', 'dumketo' ),
                'required' => array( 'activate_schema', '=', '1' ),
                'id'       => 'postalCode',
                'type'     => 'text',
            ),
        )
    );
    return $sections;
}
add_filter("redux/options/redux_builder_amp/sections", 'add_dumketo_schema');
